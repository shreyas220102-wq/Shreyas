(() => {
  "use strict";
  const STORAGE_KEY = "clat2028StudyCompanion.v1";
  const subjects = [
    {id:"english", name:"English Language", task:"Read an editorial and practise reading comprehension."},
    {id:"current", name:"Current Affairs & GK", task:"Review recent news and revise your current-affairs notes."},
    {id:"legal", name:"Legal Reasoning", task:"Practise principle-based questions and review explanations."},
    {id:"logical", name:"Logical Reasoning", task:"Solve critical-reasoning questions and check your logic."},
    {id:"quant", name:"Quantitative Techniques", task:"Practise calculations, data interpretation, or a weak topic."}
  ];
  const $ = id => document.getElementById(id);
  let data = loadData();
  let selectedDate = localDateString(new Date());

  function localDateString(date) {
    const y = date.getFullYear(), m = String(date.getMonth()+1).padStart(2,"0"), d = String(date.getDate()).padStart(2,"0");
    return `${y}-${m}-${d}`;
  }
  function parseDate(value) {
    const [y,m,d] = value.split("-").map(Number);
    return new Date(y, m-1, d, 12);
  }
  function formatDate(value, options={weekday:"short", year:"numeric", month:"short", day:"numeric"}) {
    return new Intl.DateTimeFormat("en-IN", options).format(parseDate(value));
  }
  function emptyDay() {
    return {completed:{}, minutes:"", mood:"", notes:"", scores:{}};
  }
  function loadData() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (!raw) return {};
      const parsed = JSON.parse(raw);
      return parsed && typeof parsed === "object" && !Array.isArray(parsed) ? parsed : {};
    } catch (_) { return {}; }
  }
  function saveData() {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
      $("saveStatus").textContent = "Saved automatically in this browser.";
    } catch (_) {
      $("saveStatus").textContent = "Could not save: browser storage may be disabled or full. Export a backup.";
    }
    renderSummary();
    renderRecent();
  }
  function dayFor(date=selectedDate) {
    if (!data[date] || typeof data[date] !== "object") data[date] = emptyDay();
    const day = data[date];
    day.completed = day.completed && typeof day.completed === "object" ? day.completed : {};
    day.scores = day.scores && typeof day.scores === "object" ? day.scores : {};
    return day;
  }
  function renderSubjects() {
    const day = dayFor();
    $("subjectList").innerHTML = "";
    subjects.forEach(subject => {
      const label = document.createElement("label");
      label.className = "subject-item";
      const checkbox = document.createElement("input");
      checkbox.type = "checkbox";
      checkbox.checked = Boolean(day.completed[subject.id]);
      checkbox.setAttribute("aria-label", `Mark ${subject.name} completed`);
      checkbox.addEventListener("change", () => {
        dayFor().completed[subject.id] = checkbox.checked;
        saveData(); renderDailyStatus();
      });
      const copy = document.createElement("span");
      const name = document.createElement("span"); name.className = "subject-name"; name.textContent = subject.name;
      const task = document.createElement("span"); task.className = "subject-task"; task.textContent = subject.task;
      copy.append(name, task); label.append(checkbox, copy); $("subjectList").append(label);
    });
    renderDailyStatus();
  }
  function renderDailyStatus() {
    const day = dayFor();
    const done = subjects.filter(s => day.completed[s.id]).length;
    $("completionBadge").textContent = `${done} of ${subjects.length} completed`;
    $("dailyProgress").style.width = `${done / subjects.length * 100}%`;
    $("dailyProgress").setAttribute("aria-valuenow", String(done));
    $("selectedDateTitle").textContent = formatDate(selectedDate, {weekday:"long", month:"long", day:"numeric"});
  }
  function scoreRow(subject) {
    const saved = dayFor().scores[subject.id] || {};
    const tr = document.createElement("tr");
    const name = document.createElement("td"); name.textContent = subject.name;
    const attemptedTd = document.createElement("td"), correctTd = document.createElement("td"), accuracyTd = document.createElement("td");
    const attempted = document.createElement("input"); attempted.className = "score-input"; attempted.type = "number"; attempted.min = "0"; attempted.max = "500"; attempted.step = "1"; attempted.inputMode = "numeric"; attempted.value = saved.attempted ?? ""; attempted.setAttribute("aria-label", `${subject.name} questions attempted`);
    const correct = document.createElement("input"); correct.className = "score-input"; correct.type = "number"; correct.min = "0"; correct.max = "500"; correct.step = "1"; correct.inputMode = "numeric"; correct.value = saved.correct ?? ""; correct.setAttribute("aria-label", `${subject.name} correct answers`);
    const accuracy = document.createElement("span"); accuracy.className = "accuracy";
    const updateAccuracy = () => {
      const a = Number(attempted.value), c = Number(correct.value);
      accuracy.textContent = attempted.value !== "" && a > 0 && correct.value !== "" && c <= a && c >= 0 ? `${(c/a*100).toFixed(1)}%` : "—";
    };
    attempted.addEventListener("input", updateAccuracy); correct.addEventListener("input", updateAccuracy); updateAccuracy();
    attemptedTd.append(attempted); correctTd.append(correct); accuracyTd.append(accuracy); tr.append(name, attemptedTd, correctTd, accuracyTd);
    tr.dataset.subject = subject.id;
    return tr;
  }
  function renderScores() {
    $("scoreRows").innerHTML = "";
    subjects.forEach(s => $("scoreRows").append(scoreRow(s)));
  }
  function saveScores() {
    const day = dayFor();
    let invalid = false;
    document.querySelectorAll("#scoreRows tr").forEach(row => {
      const id = row.dataset.subject, inputs = row.querySelectorAll("input");
      const aRaw = inputs[0].value.trim(), cRaw = inputs[1].value.trim();
      if (aRaw === "" && cRaw === "") { delete day.scores[id]; return; }
      const a = Number(aRaw), c = Number(cRaw);
      if (aRaw === "" || cRaw === "" || !Number.isInteger(a) || !Number.isInteger(c) || a < 0 || c < 0 || c > a || a > 500) { invalid = true; return; }
      day.scores[id] = {attempted:a, correct:c};
    });
    if (invalid) {
      $("scoreStatus").textContent = "Check scores: use whole numbers, enter both fields, and ensure correct answers do not exceed attempted.";
      return;
    }
    saveData();
    $("scoreStatus").textContent = "Scores saved for " + formatDate(selectedDate, {month:"short", day:"numeric", year:"numeric"}) + ".";
  }
  function readFields() {
    const day = dayFor();
    day.minutes = $("plannedMinutes").value;
    day.mood = $("dayMood").value;
    day.notes = $("dailyNotes").value;
  }
  function renderFields() {
    const day = dayFor();
    $("plannedMinutes").value = day.minutes ?? "";
    $("dayMood").value = day.mood ?? "";
    $("dailyNotes").value = day.notes ?? "";
  }
  function selectDate(value) {
    if (!value || !/^\d{4}-\d{2}-\d{2}$/.test(value)) return;
    selectedDate = value;
    $("studyDate").value = value;
    renderSubjects(); renderFields(); renderScores();
    $("scoreStatus").textContent = "Scores are saved with the selected date.";
    renderSummary();
  }
  function getAllScoreTotals() {
    let attempted = 0, correct = 0;
    Object.values(data).forEach(day => Object.values(day.scores || {}).forEach(s => {
      if (Number.isFinite(Number(s.attempted)) && Number.isFinite(Number(s.correct))) {
        attempted += Number(s.attempted); correct += Number(s.correct);
      }
    }));
    return {attempted, correct};
  }
  function renderSummary() {
    const dates = Object.keys(data).sort();
    let planned = 0, completed = 0;
    dates.forEach(date => subjects.forEach(s => { planned++; if (data[date]?.completed?.[s.id]) completed++; }));
    $("statTasks").textContent = planned ? `${Math.round(completed/planned*100)}%` : "0%";
    const active = new Set(dates.filter(date => subjects.some(s => data[date]?.completed?.[s.id])));
    $("statSessions").textContent = active.size;
    const totals = getAllScoreTotals();
    $("statAccuracy").textContent = totals.attempted ? `${(totals.correct/totals.attempted*100).toFixed(1)}%` : "—";
    let streak = 0, cursor = parseDate(localDateString(new Date()));
    while (true) {
      const key = localDateString(cursor);
      if (!active.has(key)) break;
      streak++;
      cursor.setDate(cursor.getDate()-1);
    }
    $("statStreak").textContent = `${streak} ${streak === 1 ? "day" : "days"}`;
  }
  function renderRecent() {
    const host = $("recentDays"), dates = Object.keys(data).sort().reverse().filter(d => {
      const day = data[d];
      return Object.values(day.completed || {}).some(Boolean) || day.notes || day.minutes || Object.keys(day.scores || {}).length;
    }).slice(0,7);
    host.innerHTML = "";
    if (!dates.length) { const p = document.createElement("p"); p.className = "muted"; p.textContent = "Your saved study days will appear here."; host.append(p); return; }
    dates.forEach(date => {
      const day = data[date], done = subjects.filter(s => day.completed?.[s.id]).length;
      const row = document.createElement("div"); row.className = "recent-item";
      const left = document.createElement("div"), title = document.createElement("div"), sub = document.createElement("div");
      title.className = "recent-date"; title.textContent = formatDate(date, {weekday:"short", month:"short", day:"numeric"});
      sub.className = "recent-sub"; sub.textContent = `${done}/5 subjects · ${day.minutes || 0} minutes`;
      left.append(title, sub);
      const pct = document.createElement("span"); pct.className = "recent-percent"; pct.textContent = `${Math.round(done/5*100)}%`;
      const open = document.createElement("button"); open.type = "button"; open.className = "button button-secondary"; open.textContent = "Open"; open.addEventListener("click", () => selectDate(date));
      row.append(left, pct, open); host.append(row);
    });
  }
  function downloadFile(filename, content, type) {
    const blob = new Blob([content], {type});
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a"); a.href = url; a.download = filename; document.body.append(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }
  function exportBackup() {
    readFields(); saveData();
    downloadFile("clat-2028-study-backup.json", JSON.stringify({app:"CLAT 2028 Study Companion", version:1, exportedAt:new Date().toISOString(), days:data}, null, 2), "application/json");
    $("backupStatus").textContent = "Backup exported. Keep it somewhere safe.";
  }
  function exportDay() {
    readFields(); saveData();
    const day = dayFor();
    const lines = [`CLAT 2028 Study Log — ${formatDate(selectedDate, {weekday:"long", year:"numeric", month:"long", day:"numeric"})}`, "", "Subjects:"];
    subjects.forEach(s => lines.push(`${day.completed[s.id] ? "[x]" : "[ ]"} ${s.name}`));
    lines.push("", `Study time: ${day.minutes || 0} minutes`, `How it went: ${day.mood || "Not recorded"}`, "", "Scores:");
    subjects.forEach(s => {
      const score = day.scores[s.id];
      lines.push(`${s.name}: ${score ? `${score.correct}/${score.attempted} correct (${(score.correct/score.attempted*100).toFixed(1)}%)` : "Not recorded"}`);
    });
    lines.push("", "Notes:", day.notes || "No notes recorded.");
    downloadFile(`clat-study-${selectedDate}.txt`, lines.join("\n"), "text/plain;charset=utf-8");
  }
  function importBackup(file) {
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const parsed = JSON.parse(String(reader.result));
        const incoming = parsed.days && typeof parsed.days === "object" ? parsed.days : parsed;
        if (!incoming || typeof incoming !== "object" || Array.isArray(incoming)) throw new Error("Invalid format");
        const clean = {};
        Object.entries(incoming).forEach(([date, day]) => {
          if (/^\d{4}-\d{2}-\d{2}$/.test(date) && day && typeof day === "object") clean[date] = day;
        });
        if (!Object.keys(clean).length) throw new Error("No valid study days found");
        data = {...data, ...clean};
        saveData(); selectDate(selectedDate);
        $("backupStatus").textContent = `Imported ${Object.keys(clean).length} study day(s).`;
      } catch (_) {
        $("backupStatus").textContent = "That file could not be imported. Choose a valid CLAT study backup JSON file.";
      }
    };
    reader.readAsText(file);
  }
  $("studyDate").addEventListener("change", e => selectDate(e.target.value));
  $("todayBtn").addEventListener("click", () => selectDate(localDateString(new Date())));
  $("yesterdayBtn").addEventListener("click", () => { const d = new Date(); d.setDate(d.getDate()-1); selectDate(localDateString(d)); });
  ["plannedMinutes","dayMood","dailyNotes"].forEach(id => $(id).addEventListener(id === "dailyNotes" ? "input" : "change", () => { readFields(); saveData(); }));
  $("saveScoresBtn").addEventListener("click", saveScores);
  $("exportBtn").addEventListener("click", exportBackup);
  $("downloadDayBtn").addEventListener("click", exportDay);
  $("clearDayBtn").addEventListener("click", () => {
    if (!confirm(`Clear all checklist items, scores, and notes for ${formatDate(selectedDate, {month:"short", day:"numeric", year:"numeric"})}? This cannot be undone unless you have a backup.`)) return;
    delete data[selectedDate];
    saveData(); selectDate(selectedDate);
  });
  $("importFile").addEventListener("change", e => { const file = e.target.files?.[0]; if (file) importBackup(file); e.target.value = ""; });
  $("todayLabel").textContent = formatDate(localDateString(new Date()), {weekday:"short", month:"short", day:"numeric"});
  $("studyDate").value = selectedDate;
  selectDate(selectedDate);
})();